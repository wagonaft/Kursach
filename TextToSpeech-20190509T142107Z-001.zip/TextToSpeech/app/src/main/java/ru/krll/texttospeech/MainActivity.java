package ru.krll.texttospeech;

import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    EditText textEdit;
    Button playButton;
    TextToSpeech tts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textEdit  = findViewById(R.id.textEdit);
        playButton = findViewById(R.id.playButton);

        playButton.setOnClickListener(v -> {
            String text = textEdit.getText().toString();

            tts = new TextToSpeech(this, status -> {
                if (status == TextToSpeech.SUCCESS) {
                    if (tts != null) {
                        int result;
                        if (tts.isLanguageAvailable(new Locale(Locale.getDefault().getLanguage()))
                                == TextToSpeech.LANG_AVAILABLE) {
                            result = tts.setLanguage(new Locale(Locale.getDefault().getLanguage()));
                        } else {
                            result = tts.setLanguage(Locale.US);
                        }

                        if (result == TextToSpeech.LANG_MISSING_DATA || result ==
                                TextToSpeech.LANG_NOT_SUPPORTED) {
                            Toast.makeText(this, "TTS language is not supported",
                                    Toast.LENGTH_LONG).show();
                        } else {
                            tts.speak(text, TextToSpeech.QUEUE_ADD, null);
                        }
                    }
                } else {
                    Toast.makeText(this, "TTS initialization failed",
                            Toast.LENGTH_LONG).show();
                }
            });
        });
    }
}
